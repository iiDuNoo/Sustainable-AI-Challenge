This folder includes 5 different IEEE testing cases, 14-bus, 30-bus, 39-bus, 57-bus, and 57-bus-modified, and their power flow solutions at different loading levels. These solutions were obtained by the holomorphic embedding based continuation (HEBC) method developed by Dr Dan Wu at MIT and Dr Bin Wang at TAMU. A paper entitled "A Holomorphic Embedding Based Continuation Method for Identifying Multiple Power Flow Solutions" is accepted by the IEEE Access. A pre-print version of this paper can be found in
https://arxiv.org/abs/1905.01602

These solution sets were presented and analyzed in our recent PES Letter entitled "On the Distribution Patterns of Power Flow Solutions".

======================================================================

Mild modifications are made to these systems to avoid numerical instability and structurally unstable solutions. 

Numerically, we made
14-bus: added 0.0005 pu resistance to the lossless lines;
30-bus: added 0.0001 pu resistance to the lossless lines;
39-bus: added 0.0001 pu resistance to the lossless lines;
57-bus: added 0.0001 pu resistance to the lossless lines.

The 57-bus-modified system is the standard 57-bus system without tap ratios. This change is not for the purpose of retaining numerical stability, but for a comparison of solution change under different system configurations.

=======================================================================

We increase the loading level for each testing case and calculate the corresponding solutions. Every load in the system is scaled at the same ratio for both the active power and the reactive power. 

These solutions are prepared for any research purposes on revealing algebraic and geometric structures of power flow problem. 

You should NOT assume that these solution sets are complete at this moment. Although the proposed method found all the solutions for all the verifiable cases, we still lack a theoretical guarantee in general. So a rigorous statement can be, these test cases at least admit such numbers of solutions. 

=======================================================================

Specifically in each .mat file, we include:

factor:     scaling factor on loads;
Vact.cmplx: actual voltage solutions in complex form;
Vact.mag:   actual voltage magnitudes;
Vact.ang:   actual voltage angles;
Vsc.cmplx:  short-circuit voltage solutions in complex form;
Vsc.mag:    short-circuit voltage magnitudes;
Vsc.ang:    short-circuit voltage angles;
mpc:        system parameters in matpower format.

The actual solutions are the power flow solutions that satisfy the power balance equations as well as the KCL.
The short-circuit solutions are the power flow solutions that satisfy the power balance equations but not the KCL. (This is because the power injection model can deny the KCL at a special situation when a PQ bus has zero power injection.)

