const mongoose = require('mongoose');
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);

var definitions = require('./definitionsSchema');
var Schema = mongoose.Schema;

var TermsOtherSchema = new Schema({
    wordEnglish: String,
    wordNonEnglish: String,
    wordExpanded: String,
    languageCode: String,
    image: String,
    imageType: String,
    audio: Date,
    audioType: String,
    linkAuthoritative: String,
    linkWikipedia: String,
    linkYoutube: String,
    authorName: String,
    dateCreated: Date,
    dateRevised: Date,
    fieldOfStudy: String,
    helpYes: Number,
    helpNo: Number,
    termEnglishId: String,
    definitions: [definitions],
  });

  module.exports = TermsOtherSchema
