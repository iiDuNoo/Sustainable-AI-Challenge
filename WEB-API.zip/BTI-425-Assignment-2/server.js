/*
Student ID: 033337155
Student Name: Nathen Gay
Date: 06-02-2020
Assignment 1
*/

// Setup
const express = require("express");
const path = require("path");
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();
const HTTP_PORT = process.env.PORT || 8080;
var cors = require('cors')

//Add support for cors()
app.use(cors());
// Add support for incoming JSON entities
app.use(bodyParser.json());
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods: POST, GET, OPTIONS, DELETE, PUT")
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

const manager = require("./manager.js");
const m = manager();


app.get("/api", (req, res) => {

    const links = [];
    // The app's resources
    links.push({ "rel": "collection", "href": "/api/termsEnglish", "methods": "GET,POST,DELETE,PUT,OPTIONS" });
    
    const linkObject = { 
      "apiName": "a2-web-api",
      "apiDescription": "Assignment 2 api",
      "apiVersion": "1.0", 
      "apiAuthor": "Nathen Gay",
      "links": links
    };
    res.json(linkObject);
  });


// Home Page
app.get("/", (req,res) => {
    res.sendFile(path.join(__dirname, "/index.html"));
});
  //----------------------------------------------TermsEnglish----------------------------------------------------------------------------
// Get all
app.get("/api/TermsEnglish", (req, res) => {

  m.termsEnglishGetAll()
      .then((data) => {
        res.json(data);
      })
      .catch((error) => {
        res.status(500).json({ "message": error });
      })
  });
  // Get one
  app.get("/api/TermsEnglish/:id", (req, res) => {

    m.termsEnglishGetById(req.params.id)
      .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });
  //get one (or some) by wordEnglish
  app.get("/api/TermsEnglish/word/:text", (req, res) => {

    m.termsEnglishGetBywordEnglish(req.params.text)
      .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });

  // Add new
  app.post("/api/TermsEnglish", (req, res) => {

    m.termsEnglishAdd(req.body)
      .then((data) => {
        res.json(data);
      })
      .catch((error) => {
        res.status(500).json({ "message": error });
      })
  });
  
  // Edit existing - add new definition
  app.put("/api/TermsEnglish/:id/add-definition", (req, res) => {

    m.termsEnglishAddDefinitionEdit(req.params.id, req.body)
      .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });
  
  //Increment helpYes
  app.put("/api/TermsEnglish/helpYes/:id", (req, res) => {
    // Call the manager method
    m.termsEnglishIncrementHelpYes(req.params.id, req.body)
      .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });

    //Increment helpNo
    app.put("/api/TermsEnglish/helpNo/:id", (req, res) => {
      // Call the manager method
      m.termsEnglishIncrementHelpNo(req.params.id, req.body)
        .then((data) => {
          res.json(data);
        })
        .catch(() => {
          res.status(404).json({ "message": "Resource not found" });
        })
    });

    //Increment definitions likes
    app.put("/api/TermsEnglish/definitionLike/:id", (req, res) => {
      // Call the manager method
      m.termsEnglishDefinitionLikesIncrement(req.params.id)
        .then((data) => {
          res.json(data);
        })
        .catch(() => {
          res.status(404).json({ "message": "Resource not found" });
        })
    });
    
  /*
  // Delete item
  app.delete("/api/vehicles/:id", (req, res) => {

    m.vehicleDelete(req.params.id)
      .then(() => {
        res.status(204).end();
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });
  */
  
    //----------------------------------------------TermsOther----------------------------------------------------------------------------
    // Get all
app.get("/api/TermsOther", (req, res) => {

  m.termsOtherGetAll()
      .then((data) => {
        res.json(data);
      })
      .catch((error) => {
        res.status(500).json({ "message": error });
      })
  });
  // Get one
  app.get("/api/TermsOther/:id", (req, res) => {

    m.termsOtherGetById(req.params.id)
    .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });
//Get Some
 app.get("/api/TermsOther/word/:text", (req, res) => {
    m.termsOtherGetBywordNonEnglish(req.params.text)
      .then((data) => {
        res.json(data);
      })
      .catch(() => {
        res.status(404).json({ "message": "Resource not found" });
      })
  });

  // Add new
  app.post("/api/TermsOther", (req, res) => {

    m.termsOtherAdd(req.body)
      .then((data) => {
        res.json(data);
      })
      .catch((error) => {
        res.status(500).json({ "message": error });
      })
  });

    // Edit existing - add new definition
    app.put("/api/TermsOther/:id/add-definition", (req, res) => {

      m.termsOtherAddDefinitionEdit(req.params.id, req.body)
        .then((data) => {
          res.json(data);
        })
        .catch(() => {
          res.status(404).json({ "message": "Resource not found" });
        })
    });
    
    //Increment helpYes
    app.put("/api/TermsOther/helpYes/:id", (req, res) => {
      // Call the manager method
      m.termsOtherIncrementHelpYes(req.params.id, req.body)
        .then((data) => {
          res.json(data);
        })
        .catch(() => {
          res.status(404).json({ "message": "Resource not found" });
        })
    });
  
      //Increment helpNo
      app.put("/api/TermsOther/helpNo/:id", (req, res) => {
        // Call the manager method
        m.termsOtherIncrementHelpNo(req.params.id, req.body)
          .then((data) => {
            res.json(data);
          })
          .catch(() => {
            res.status(404).json({ "message": "Resource not found" });
          })
      });
  
      //Increment definitions likes
      app.put("/api/TermsOther/definitionLike/:id", (req, res) => {
        // Call the manager method
        m.termsOtherDefinitionLikesIncrement(req.params.id)
          .then((data) => {
            res.json(data);
          })
          .catch(() => {
            res.status(404).json({ "message": "Resource not found" });
          })
      });
      
  
  //----------------------------------------------------------------------------------------------------------------------------
  // Resource not found  
  app.use((req, res) => {
    res.status(404).send("Resource not found");
  });
  

  m.connect().then(() => {
    app.listen(HTTP_PORT, () => { console.log("Ready to handle requests on port " + HTTP_PORT) });
 
  })
    .catch((err) => {
      console.log("Unable to start the server:\n" + err);
      process.exit();
    });
  
