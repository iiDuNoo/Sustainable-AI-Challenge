//THIS IS FOR DATA SERVICE TASKS
const mongoose = require('mongoose');
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);


const TermsEnglishSchema = require("./TermsEnglishschema.js");
let TermsEnglish;

const TermsOtherSchema = require('./TermsOtherschema.js');
let TermsOther;


module.exports = function () {


  return {

    // Connect to the database

    connect: function () {
      return new Promise(function (resolve, reject) {


        console.log('Attempting to connect to the database...');

        //connect to mongoDB atlas
        mongoose.connect('mongodb+srv://negay:Roadtrip45@assignments-zkik1.mongodb.net/Assignment_2?retryWrites=true&w=majority', { connectTimeoutMS: 5000, useUnifiedTopology: true });

        var db = mongoose.connection;
        var db2 = mongoose.connection;

        //can't connect to database
        db.on('error', (error) => {
          console.log('Connection error:', error.message);
          reject(error);
        });

        // Handle the open/connected event scenario
        db.once('open', () => {
          console.log('Connection to the database was successful');
          TermsEnglish = db.model("TermsEnglish", TermsEnglishSchema, "TermsEnglish")
          TermsOther = db2.model("TermsOther", TermsOtherSchema, "TermsOther")
          resolve();
        });
      });
    },
    //GET ALL
    termsEnglishGetAll: function () {
      return new Promise(function (resolve, reject) {

        //get all
        TermsEnglish.find()
          .sort({ wordEnglish: 'asc'})
          .exec((error, items) => {
            if (error) {
              // Query error
              return reject(error.message);
            }
            // Found, a collection will be returned
            return resolve(items);
          });
      })
    },
    //GET ONE BY ID
    termsEnglishGetById: function (itemId) {
      return new Promise(function (resolve, reject) {

        // get one
        TermsEnglish.findById(itemId, (error, item) => {
          if (error) {

            return reject(error.message);
          }

          if (item) {

            return resolve(item);
          } else {
            return reject('Not found');
          }
        });
      })
    },
    //Get one (or some) by "wordEnglish"
    termsEnglishGetBywordEnglish: async function (text) {
      //URL decode incoming value
      text = decodeURIComponent(text);

      //search TermsEnglish for 0 ... * terms 'text'
      let results = await TermsEnglish.find({ wordEnglish: { $regex: text, $options: "i" } })

      return results;
    },

    //add a term to collection
    termsEnglishAdd: function (newItem) {
      return new Promise(function (resolve, reject) {

        TermsEnglish.create(newItem, (error, item) => {
          if (error) {

            return reject(error.message);
          }

          return resolve(item);
        });
      })
    },

    //edit term in collection
    termsEnglishAddDefinitionEdit: async function (itemId, newItem) {

      // Attempt to locate the existing document
      let term = await TermsEnglish.findById(itemId);

      if (term) {
        // Add the new subdocument and save
        term.definitions.push(newItem);
        await term.save(function (err) {
          if (err) {
            console.log(err);
          }
          else {
            return term;
          }
        });
      }
      else {
        // Uh oh, "throw" an error
        throw "Not found";
      }
    },
    //Increment helpYes
    termsEnglishIncrementHelpYes: async function (itemId, newItem) {
      let term = await TermsEnglish.findById(itemId);

      if (term) {

        term.helpYes++;
        await term.save();
        return term;
      }
      else {
        throw "Not Found";
      }
    },
    //Increment helpNo
    termsEnglishIncrementHelpNo: async function (itemId, newItem) {
      let term = await TermsEnglish.findById(itemId);

      if (term) {

        term.helpNo++;
        await term.save();
        return term;
      }
      else {
        throw "Not Found";
      }
    },
    //Increment definition likes value
    termsEnglishDefinitionLikesIncrement: async function (itemId) {

      // Attempt to locate the existing document that has the desired department
      let term = await TermsEnglish.findOne({ "definitions._id": itemId });

      if (term) {
        // Attempt to locate the department
        let def = term.definitions.id(itemId);
        // Increment and save
        def.likes++;
        await term.save();
        // Send the entire document back to the requestor
        return term;
      }
      else {
        // Uh oh, "throw" an error
        throw "Not found";
      };
    },

    //--------------------------------------------------------------Terms Other-------------------------------------------------------
    termsOtherGetAll: function () {
      return new Promise(function (resolve, reject) {

        //get all
        TermsOther.find()
          //.sort({ make: 'asc', model: 'asc', year: 'asc'})
          .exec((error, items) => {
            if (error) {
              // Query error
              return reject(error.message);
            }
            // Found, a collection will be returned
            return resolve(items);
          });
      })
    },

    termsOtherGetById: function (itemId) {
      return new Promise(function (resolve, reject) {

        // get one
        TermsOther.findById(itemId, (error, item) => {
          if (error) {

            return reject(error.message);
          }

          if (item) {

            return resolve(item);
          } else {
            return reject('Not found');
          }
        });
      })
    },
    //Get one (or some) by "wordNonEnglish"
    termsOtherGetBywordNonEnglish: async function (text) {
      //URL decode incoming value
      text = decodeURIComponent(text)

      //search TermsEnglish for 0 ... * terms 'text'
      let results = await TermsOther.find({ wordNonEnglish: { $regex: text, $options: "i" } })

      return results;
    },
    //add a vehicle to collection
    termsOtherAdd: function (newItem) {
      return new Promise(function (resolve, reject) {

        TermsOther.create(newItem, (error, item) => {
          if (error) {

            return reject(error.message);
          }

          return resolve(item);
        });
      })
    },

    //edit term in collection
    termsOtherAddDefinitionEdit: async function (itemId, newItem) {

      // Attempt to locate the existing document
      let term = await TermsOther.findById(itemId);

      if (term) {
        // Add the new subdocument and save
        term.definitions.push(newItem);
        await term.save(function (err) {
          if (err) {
            console.log(err);
          }
          else {
            return term;
          }
        });
      }
      else {
        // Uh oh, "throw" an error
        throw "Not found";
      }
    },
    //Increment helpYes
    termsOtherIncrementHelpYes: async function (itemId, newItem) {
      let term = await TermsOther.findById(itemId);

      if (term) {
        term.helpYes++;
        await term.save();
        return term;
      }
      else {
        throw "Not Found";
      }
    },
    //Increment helpNo
    termsOtherIncrementHelpNo: async function (itemId, newItem) {
      let term = await TermsOther.findById(itemId);

      if (term) {

        term.helpNo++;
        await term.save();
        return term;
      }
      else {
        throw "Not Found";
      }
    },
    //Increment definition likes value
    termsOtherDefinitionLikesIncrement: async function (itemId) {

      // Attempt to locate the existing document that has the desired department
      let term = await TermsOther.findOne({ "definitions._id": itemId });

      if (term) {
        // Attempt to locate the department
        let def = term.definitions.id(itemId);
        // Increment and save
        def.likes++;
        await term.save();
        // Send the entire document back to the requestor
        return term;
      }
      else {
        // Uh oh, "throw" an error
        throw "Not found";
      };
    },
  }
}
