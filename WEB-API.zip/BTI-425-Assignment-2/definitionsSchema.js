const mongoose = require('mongoose');
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);

var Schema = mongoose.Schema;


var definition = new Schema({
  authorName: String,
  dateCreated: Date,
  definition: String,
  quality: Number,
  likes: Number,


})

module.exports = definition;
